n = int(raw_input("How big is the square? "))

for number in range(n):
    print "*" * n
