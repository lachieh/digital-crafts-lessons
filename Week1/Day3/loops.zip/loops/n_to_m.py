number1 = int(raw_input("Start from: "))
number2 = int(raw_input("End on: "))

for number in range(number1, number2 + 1):
    print number
