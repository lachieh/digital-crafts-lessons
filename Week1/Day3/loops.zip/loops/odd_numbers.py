for number in range(20, 33):
    if number % 2:
        print number
