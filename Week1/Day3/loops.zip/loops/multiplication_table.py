n = 10

for number1 in range(1, n + 1):
    for number2 in range(1, n + 1):
        result = number1 * number2
        print "%d x %d = %d" % (number1, number2, result)
