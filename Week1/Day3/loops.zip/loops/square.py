n = 5

for number in range(n):
    print "*" * n
