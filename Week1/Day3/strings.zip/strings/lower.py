stringToLower = raw_input("lowercase this: ")

print "lowercased word: %s" % stringToLower.lower()
