stringToCaps = raw_input("Capitalize this: ")

print "Caps word: %s" % stringToCaps.capitalize()
