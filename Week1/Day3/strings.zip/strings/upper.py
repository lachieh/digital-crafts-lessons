stringToUpper = raw_input("uppercase this: ")

print "uppercased word: %s" % stringToUpper.upper()
