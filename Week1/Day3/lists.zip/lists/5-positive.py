numbers = [2, 3, 6, -10, -4, 0, 9, 32, 5]

for number in numbers:  # for each number in the list
    if number >= 0:  # if the current number is greater than or equal to zero
        print number  # print the current numbers
