numbers = [2, 3, 6, -10, -4, 0, 9, 32, 5]

for number in numbers:  # for each number the numbers list
    if number % 2 == 0:  # if there is no remainder after dividing by 2
        print number  # print the current number
